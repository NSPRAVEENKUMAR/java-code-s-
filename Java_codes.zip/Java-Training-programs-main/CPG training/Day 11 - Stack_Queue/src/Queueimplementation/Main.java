package Queueimplementation;

public class Main {
    public static void main(String[] args) {
        Queue q=new Queue();
        q.enque(10);
        q.enque(20);
        q.enque(30);
        q.display();
        q.deque();
        //q.peek();
        q.display();

    }
}
