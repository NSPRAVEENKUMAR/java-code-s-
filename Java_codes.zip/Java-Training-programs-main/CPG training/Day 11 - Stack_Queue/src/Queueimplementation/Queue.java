package Queueimplementation;

public class Queue {
    int[] a=new int[5];
    int front=-1;
    int rear=-1;
    public void enque(int data)
    {
       if(front==-1 && rear==-1){
           front++;
           rear++;
           a[rear]=data;
       }
       else{
           rear++;
           a[rear]=data;
       }
    }
    public void deque()
    {
        if(front==-1 && rear==-1){
            System.out.println("Stack is empty");
        }
        else{
            System.out.println("deque");
            front++;
        }
    }
//    public void peek(){
//        System.out.println(a[rear]);
//    }

    public void display(){
        for(int i= front;i<=rear;i++){
            System.out.println(a[i]);
        }
    }
}
