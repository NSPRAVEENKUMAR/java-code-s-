package Stackexample;

import StackImplementation.Stack;

public class Main {
    public static void main(String[] args) {
        StackImplementation.Stack s= new Stack();
        s.push(10);
        s.push2(20);
        s.push(30);
        s.push2(40);
        s.push(50);
        s.pop();
        s.pop2();
        s.peek();
        s.display();
        s.display2();
    }
}

