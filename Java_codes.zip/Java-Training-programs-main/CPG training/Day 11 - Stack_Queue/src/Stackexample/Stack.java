package Stackexample;

public class Stack {
    // stack

    int a[] = new int[10];
    public int top =-1;
    public int top2 =a.length/2;

    // push ()

    public void push(int data){
        if(top==top2-1){
            System.out.println("Stack is full");
        }
        else{
            top++;
            a[top]=data;
        }
    }

    public void push2(int data){
        if(top2==a.length-1){
            System.out.println("Stack is full");
        }
        else{
            top2++;
            a[top2]=data;
        }
    }

    // pop()

    public void pop(){
        if(top==-1){
            System.out.println("Stack is empty");
        }
        else{
            top--;
        }
    }
    public void pop2(){
        if(top2==(a.length/2)-1){
            System.out.println("Stack is empty");
        }
        else{
            top2--;
        }
    }

    // peek()

    public void peek(){
        if(top==-1){
            System.out.println("Stack is empty");
        }
        else{
            System.out.println("Top of the element:" + a[top]);
        }
    }

    public void display(){
        for(int i=top;i>=0;i--){
            System.out.println(a[i]);
        }
    }
    public void display2(){
        for(int i=top2;i>=a.length;i--){
            System.out.println(a[i]);
        }
    }
}
