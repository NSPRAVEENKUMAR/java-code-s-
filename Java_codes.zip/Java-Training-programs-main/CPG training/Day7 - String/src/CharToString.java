public class CharToString {
    public static void main(String[] args) {
        char[] ch={'v','e','n','k','a','t','e','s','h'};
        String s=new String(ch);
        System.out.println(s);
    }
}
