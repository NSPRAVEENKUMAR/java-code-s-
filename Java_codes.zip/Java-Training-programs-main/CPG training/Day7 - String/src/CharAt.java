public class CharAt {
    public static void main(String[] args) {
        String str=new String("Hello");
        char a=str.charAt(3);
        System.out.println(a);
    }
}
