import java.lang.*;
public class Concat {
    public static void main(String[] args) {
        String str1="Hello";
        String str2="World";
        //String a= a.concat(str1,str2);
        //System.out.println(a);
        System.out.println(str1+" "+str2);
    }
}
