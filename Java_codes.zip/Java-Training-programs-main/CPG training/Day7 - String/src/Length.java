public class Length {
    public static void main(String[] args) {
        //using length method
        String str=new String("Hello");
        System.out.println(str.length());
    }
}
