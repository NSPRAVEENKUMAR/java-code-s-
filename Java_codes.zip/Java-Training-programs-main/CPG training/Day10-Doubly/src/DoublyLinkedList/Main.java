package DoublyLinkedList;

public class Main {
    public static void main(String[] args) {
        DoublyLL DLL = new DoublyLL();
        DLL.insertatend(300);
        DLL.insertatend(400);
        DLL.insertAtBegin(100);
        DLL.insertmiddle(200,1);
        DLL.reverse();
//        DLL.delete();
//        DLL.deleteEnd();
        DLL.display();
    }
}
