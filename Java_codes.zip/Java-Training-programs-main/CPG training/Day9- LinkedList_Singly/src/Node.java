public class Node {
}
class demo{}