public class Main {
    public static void main(String[] args) {
        Main m1= new Main(1);
        m1.d();
    }
    void d(){
        System.out.println("hello");
    }

    Main(int a)
    {
        System.out.println("hello c2");
    }

}